ELASTIC GROTESQUE / GUT COMBO

Extract this folder to a permanent location. Open Enable Auto Launch.cmd
once to start the hidden watcher now and at Windows sign-in. It shows the
meter when the match feed becomes available and hides it after the match.
Use Borderless mode or a second monitor. Drag to place it. Esc or × hides
it for the current match. Disable Auto Launch.cmd stops the watcher and
removes its startup shortcut.

Launch Gut Combo.cmd also opens the meter manually.
The app uses Python 3.10+ with Tkinter. It needs no Python packages.

Each scoreboard CS is one point, each assist is four, and each kill is six.
A CS gain flashes the feed label, nudges the stomach, and gives the chain
35 seconds to find the next bite. Kills and assists give 60 seconds and
feed the stomach with soul blobs. They melt into fluid, but their faces
travel through the coils and float in the collector. All CS from a
batched scoreboard update still count, with a bite cue for each point.
Starting the app mid-match sets a baseline from the current scoreboard.

Score goes into the stomach first. About every three seconds, the stomach
squeezes a portion through the intestinal coils. That bolus raises the fluid
level in the collector when it arrives. When the combo drops, the collector
drains into the colon. Each face opens in a scream, sheds tears, and is
pulled whole into the wall in a trail of ghostly afterimages.
Packed mud stays there across combos. Death clears
the tract. A match end freezes the final state.
Green wisps and gurgles run during a combo. The music-note button or M
toggles the gurgles.

Absorbed faces spend nine seconds in the heart, pulsing smaller before
they become bladder points. A kill yields six bladder points and an
assist four. Click $ at the top to open the aura shop. Compacted mud and
bladder points buy extra whisper text, soul sparks, and low gurgles.
Purchases last the current match. Death clears unspent mud, heart souls,
and bladder points. Recall releases mud while the heart and bladder retain
their reserves. These companion effects appear around the desktop meter.

Preview Gut Combo.cmd opens the same widget in manual demo mode.
Click the window for focus. Use 1 for CS, 2 for a kill, 3 for an assist,
0 to drop the combo, 5 to start a recall, 6 to cancel it, 7 for death,
4 to end the demo match, and R to reset. The recall releases at seven
seconds in the preview. The companion has no verified live recall signal.

Use skin build 039 if you want to remove build 040's on-model passive meter.
