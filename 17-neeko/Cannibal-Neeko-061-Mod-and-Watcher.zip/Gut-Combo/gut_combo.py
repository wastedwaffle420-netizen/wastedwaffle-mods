"""An independent desktop meter for your visible League scoreboard totals."""
import argparse
from collections import deque
import ctypes
from ctypes import wintypes
from dataclasses import dataclass
import http.client
import json
import math
from pathlib import Path
from queue import Empty, Queue
import random
import ssl
from threading import Event, Thread
import time
import tkinter as tk
from urllib.parse import urlencode
import winsound


TAKEDOWN_WINDOW = 60.0
CS_WINDOW = 35.0
MAX_POLL_GAP = 12.0
FRAME_COUNT = 50
BOWEL_FRAMES = 49
AUTO_HIDE_DELAY = 8.0
RECALL_RELEASE = 7.0
COMPACTION_TIME = 1.8
FACE_ABSORB_TIME = 1.35
FACE_STAGGER = .62
HEART_HOLD = 9.0
FLOCK_LIMIT = 6
VISIT_INTERVAL = 14.0
FIRST_VISIT = 5.0
EMPTY_VISIT = 2.25
ESCAPE_TIME = 1.25
FLIGHT_TIME = 1.65
WATCH_TIME = 1.55
DIVE_TIME = .40
CHEW_TIME = 1.02
GULP_TIME = .44
SWALLOW_TIME = CHEW_TIME + GULP_TIME
CONTACT_TIME = FLIGHT_TIME + WATCH_TIME + DIVE_TIME
BUTTERFLY_SEQUENCE = CONTACT_TIME + SWALLOW_TIME
AURA_TIME = 15.0
HERE = Path(__file__).resolve().parent
SHOP = {
    'whispers': ('Whisper chorus', 12, 0, 'More voices in the green wisps'),
    'sparks': ('Soul sparks', 0, 6, 'Small skulls and violet sparks'),
    'gurgles': ('Deep gurgles', 8, 4, 'Three lower bubbling sounds'),
}


@dataclass(frozen=True)
class Snapshot:
    player: str
    clock: float
    scores: tuple[int, int, int, int]
    ended: bool = False


@dataclass(frozen=True)
class Slime:
    seconds: float
    mass: float
    reason: str

    @property
    def size(self):
        return min(10, 1 + int(self.seconds / 20 + self.mass / 15))


@dataclass(frozen=True)
class Soul:
    born: float
    amount: int
    lane: int

    @property
    def melt_at(self):
        return self.born + (5.2 if self.amount == 6 else 4.2)


@dataclass(frozen=True)
class Butterfly:
    identity: int
    born: float
    kill: bool


@dataclass(frozen=True)
class HeartSoul:
    entered: float
    soul: Soul


@dataclass(frozen=True)
class Compaction:
    start: float
    mass: float
    seconds: float
    faces: tuple[Soul, ...]

    @property
    def duration(self):
        return max(COMPACTION_TIME, .42 + max(0, len(self.faces)-1)*FACE_STAGGER + FACE_ABSORB_TIME)

    def face_progress(self, clock, index):
        return (clock-self.start-.42-index*FACE_STAGGER)/FACE_ABSORB_TIME


class Digestion:
    PULSE_INTERVAL = 3.1
    TRAVEL_TIME = 2.15

    def __init__(self):
        self.stomach = 0.0
        self.collected = 0.0
        self.bolus = 0.0
        self.departure = None
        self.next_pulse = None
        self.souls = []
        self.liquid_faces = []
        self.bolus_faces = []
        self.collector_faces = []
        self.soul_count = 0

    def feed(self, clock, cs, kills, assists):
        self.advance(clock)
        self.add_liquid(clock, cs)
        for amount, count in ((6, kills), (4, assists)):
            for _ in range(count):
                self.souls.append(Soul(clock, amount, self.soul_count))
                self.soul_count += 1

    def add_liquid(self, clock, amount):
        self.stomach += amount
        if amount and self.next_pulse is None:
            self.next_pulse = clock + self.PULSE_INTERVAL

    def advance(self, clock):
        while True:
            soul = min(self.souls, key=lambda item: item.melt_at, default=None)
            pulse = self.next_pulse if self.next_pulse is not None else math.inf
            if soul is not None and soul.melt_at <= min(clock, pulse):
                self.add_liquid(soul.melt_at, soul.amount)
                self.souls.remove(soul)
                self.liquid_faces.append(soul)
                continue
            if pulse > clock:
                break
            self.arrive(pulse)
            if not self.stomach:
                self.next_pulse = None
                continue
            self.bolus = min(self.stomach, max(2.0, self.stomach * .72))
            self.stomach -= self.bolus
            self.bolus_faces, self.liquid_faces = self.liquid_faces, []
            self.departure = pulse
            self.next_pulse = pulse + self.PULSE_INTERVAL
        self.arrive(clock)

    @property
    def mass(self):
        return self.stomach + self.collected + self.bolus + sum(soul.amount for soul in self.souls)

    @property
    def faces(self):
        return (*self.collector_faces, *self.bolus_faces, *self.liquid_faces, *self.souls)

    def arrive(self, clock):
        if self.departure is not None and clock - self.departure >= self.TRAVEL_TIME:
            self.collected += self.bolus
            self.collector_faces.extend(self.bolus_faces)
            self.bolus_faces.clear()
            self.bolus = 0.0
            self.departure = None


class Combo:
    def __init__(self):
        self.previous = None
        self.clear_match()

    def clear_match(self):
        self.points = 0
        self.first = self.last = 0.0
        self.deadline = 0.0
        self.window = TAKEDOWN_WINDOW
        self.best = 0
        self.slimes = []
        self.last_release = ''
        self.ended = False
        self.ended_at = None
        self.last_feed = ''
        self.digestion = Digestion()
        self.packed = self.packed_seconds = 0.0
        self.compacting = []
        self.cs_cues = deque()
        self.recall_started = None
        self.recall_released = False
        self.heart = []
        self.bladder = 0
        self.transferred_faces = set()
        self.upgrades = set()
        self.butterflies = deque()
        self.butterfly_serial = 0
        self.claimed_butterfly = None
        self.swallow_at = None
        self.next_visit = None
        self.aura_at = None
        self.escaping = []

    def advance_butterflies(self, clock):
        self.escaping = [(bug, start) for bug, start in self.escaping if clock < start + ESCAPE_TIME]
        if self.ended:
            return
        if self.swallow_at is not None:
            bug = self.claimed_butterfly
            duration = BUTTERFLY_SEQUENCE if bug is not None else EMPTY_VISIT
            if clock < self.swallow_at + duration:
                return
            if bug is not None:
                finished = self.swallow_at + duration
                self.expire(finished)
                self.credit(finished,kills=int(bug.kill),assists=int(not bug.kill))
                self.aura_at = finished
            self.swallow_at = None
            self.claimed_butterfly = None
        if self.next_visit is None:
            self.next_visit = clock + FIRST_VISIT
        if clock >= self.next_visit:
            self.swallow_at = clock
            self.claimed_butterfly = self.butterflies.popleft() if self.butterflies else None
            self.next_visit = clock + VISIT_INTERVAL

    def clear_chain(self):
        self.points = 0
        self.deadline = 0.0
        self.digestion = Digestion()
        self.cs_cues.clear()

    def compact(self, clock):
        gut = self.digestion
        if self.compacting:
            previous = self.compacting[-1]
            clock = max(clock, previous.start+previous.duration)
        self.compacting.append(Compaction(clock, gut.mass, self.last - self.first, gut.faces))
        self.clear_chain()

    def settle_compaction(self, clock):
        for batch in self.compacting:
            for index, soul in enumerate(batch.faces):
                token = (batch.start, index)
                absorbed_at = batch.start+.42+index*FACE_STAGGER+FACE_ABSORB_TIME
                if clock >= absorbed_at and token not in self.transferred_faces:
                    self.heart.append(HeartSoul(absorbed_at, soul))
                    self.transferred_faces.add(token)
        while self.compacting and clock >= self.compacting[0].start + self.compacting[0].duration:
            finished = self.compacting.pop(0)
            self.packed += finished.mass
            self.packed_seconds += finished.seconds
        waiting = []
        for face in self.heart:
            if clock >= face.entered+HEART_HOLD:
                self.bladder += face.soul.amount
            else:
                waiting.append(face)
        self.heart = waiting

    def buy(self, key):
        if key not in SHOP or key in self.upgrades or self.ended:
            return False
        _, mud, spirit, _ = SHOP[key]
        if self.packed < mud or self.bladder < spirit:
            return False
        self.packed -= mud
        self.bladder -= spirit
        self.upgrades.add(key)
        return True

    def release(self, reason):
        mass = self.packed + self.digestion.mass + sum(batch.mass for batch in self.compacting)
        seconds = self.packed_seconds + sum(batch.seconds for batch in self.compacting)
        if self.points:
            seconds += self.last - self.first
        if mass and reason == 'Recall':
            self.slimes.append(Slime(seconds, mass, reason))
        if mass or reason == 'Death':
            self.last_release = reason
        self.clear_chain()
        self.compacting.clear()
        self.packed = self.packed_seconds = 0.0
        if reason == 'Death':
            self.heart.clear()
            self.bladder = 0
            self.butterflies.clear()
            self.escaping.clear()
            self.claimed_butterfly = None
            self.swallow_at = None
            self.aura_at = None

    def begin_recall(self, clock):
        if not self.ended and self.recall_started is None:
            self.recall_started = clock
            self.recall_released = False

    def cancel_recall(self):
        self.recall_started = None
        self.recall_released = False

    def advance_recall(self, clock):
        if (self.recall_started is not None and not self.recall_released
                and clock - self.recall_started >= RECALL_RELEASE):
            self.release('Recall')
            self.recall_released = True
        if self.recall_started is not None and clock - self.recall_started >= 8:
            self.cancel_recall()

    def feed(self, clock, cs=0, kills=0, assists=0):
        for is_kill, count in ((True,kills),(False,assists)):
            for _ in range(count):
                self.butterfly_serial += 1
                if len(self.butterflies) >= FLOCK_LIMIT:
                    self.escaping.append((self.butterflies.popleft(), clock))
                self.butterflies.append(Butterfly(self.butterfly_serial,clock,is_kill))
        self.credit(clock,cs)

    def credit(self, clock, cs=0, kills=0, assists=0):
        gain = cs + 6*kills + 4*assists
        if not gain:
            return
        if not self.points:
            self.first = clock
        self.last = clock
        window = TAKEDOWN_WINDOW if kills or assists else CS_WINDOW
        if clock + window > self.deadline:
            self.deadline = clock + window
            self.window = window
        self.points += gain
        self.digestion.feed(clock, cs, kills, assists)
        self.cs_cues.extend(['+1 CS'] * cs)
        self.best = max(self.best, self.points)
        self.last_feed = '  '.join(f'+{count} {name}' for count, name in
                                  ((kills, 'K'), (assists, 'A'), (cs, 'CS')) if count)

    def expire(self, clock):
        if self.points and clock >= self.deadline:
            self.compact(self.deadline)

    def update(self, current):
        old = self.previous
        new_match = (old is None or old.player != current.player or current.clock < old.clock - 2
                     or (self.ended and not current.ended))
        if new_match:
            self.clear_match()
            old = None
        self.previous = current
        if self.ended:
            return False
        if old is not None:
            if not current.ended:
                self.expire(current.clock)
            cs, kills, assists, deaths = (max(0, b-a) for a, b in zip(old.scores, current.scores))
            # Cumulative totals cannot establish a combo across a missed window.
            if current.clock - old.clock < MAX_POLL_GAP:
                self.feed(current.clock, cs, kills, assists)
            if deaths:
                self.release('Death')
                self.cancel_recall()
        if current.ended:
            self.ended = True
            self.ended_at = current.clock
            self.cancel_recall()
            self.cs_cues.clear()
        return new_match


def read_game(stop, snapshots):
    """Read fixed Riot loopback endpoints. Certificate handling stays on that socket."""
    context = ssl._create_unverified_context()
    player = None
    last_clock = None
    while not stop.is_set():
        connection = http.client.HTTPSConnection('127.0.0.1', 2999, timeout=0.8, context=context)
        try:
            def get(endpoint):
                connection.request('GET', '/liveclientdata/' + endpoint)
                response = connection.getresponse()
                if response.status != 200:
                    raise OSError(f'Live client HTTP {response.status}')
                return json.loads(response.read())

            clock = float(get('gamestats')['gameTime'])
            if player is None or (last_clock is not None and clock < last_clock - 2):
                player = get('activeplayername')
            scores = get('playerscores?' + urlencode({'riotId': player}))
            events = get('eventdata')['Events']
            ended = any(event['EventName'] == 'GameEnd' for event in events)
            last_clock = clock
            totals = tuple(int(scores[key]) for key in ('creepScore', 'kills', 'assists', 'deaths'))
            snapshots.put(Snapshot(player, clock, totals, ended))
        except (OSError, ValueError, KeyError, TypeError, http.client.HTTPException):
            player = None
            snapshots.put(None)
        finally:
            connection.close()
        stop.wait(0.85)


class Meter:
    BG = '#191820'
    BONE = '#edd6cb'
    GREEN = '#cbdc89'
    MUTED = '#ad959c'

    def __init__(self, root, demo, auto=False):
        self.root = root
        self.demo = demo
        self.auto = auto
        self.visible = not auto
        self.dismissed = False
        self.end_time = None
        if auto:
            root.withdraw()
        self.combo = Combo()
        self.snapshots = Queue()
        self.stop = Event()
        self.online = demo
        self.started = time.monotonic()
        self.sample_time = self.started
        self.stomach_fill = 0.0
        self.collector_fill = 0.0
        self.packed_fill = 0.0
        self.cs_cue_until = 0.0
        self.sound = True
        self.aura_active = False
        self.aura_start = None
        self.shop_window = None
        self.butterfly_window = None
        self.swallow_window = None
        self.flock_windows = {}
        self.butterfly_id = None
        self.shop_buttons = {}
        self.next_sound = 0.0
        self.slime_frame = None
        self.origin = (0, 0)
        root.title('Elastic Grotesque | Gut Combo')
        root.geometry('310x275+65+85')
        root.resizable(False, False)
        root.attributes('-topmost', True)
        root.overrideredirect(True)
        root.protocol('WM_DELETE_WINDOW', self.close)
        self.canvas = c = tk.Canvas(root, width=310, height=275, bg=self.BG, highlightthickness=0)
        c.pack()
        c.create_rectangle(1, 1, 308, 273, outline='#6a3f52')
        c.create_rectangle(2, 2, 307, 28, fill='#302332', outline='')
        self.label(12, 15, 'ELASTIC GROTESQUE   /   GUT COMBO', size=9)
        close = self.label(291, 15, '×', size=15)
        c.tag_bind(close, '<ButtonRelease-1>', lambda _: self.dismiss())
        self.sound_button = self.label(269, 15, '♪', size=12, color=self.GREEN)
        c.tag_bind(self.sound_button, '<ButtonRelease-1>', lambda _: self.toggle_sound())
        shop_button = self.label(247, 15, '$', size=12, color='#d0a47a')
        c.tag_bind(shop_button, '<ButtonRelease-1>', lambda _: self.open_shop())
        c.bind('<ButtonPress-1>', self.grab)
        c.bind('<B1-Motion>', self.drag)
        root.bind('<Escape>', lambda _: self.dismiss())
        root.bind('m', lambda _: self.toggle_sound())
        self.stomach_frames = self.load_frames('gut.png', FRAME_COUNT, 5)
        self.bowel_frames = self.load_frames('bowel.png', BOWEL_FRAMES)
        self.bowel_route = json.loads((HERE / 'bowel-route.json').read_text(encoding='utf-8'))
        self.collector_frames = self.load_frames('collector.png', FRAME_COUNT)
        self.compaction_frames = self.load_frames('compactor.png', FRAME_COUNT)
        self.bowel = c.create_image(70, 94, image=self.bowel_frames[0][0])
        self.collector = c.create_image(70, 94, image=self.collector_frames[0][0])
        self.stomach = c.create_image(70, 94, image=self.stomach_frames[0][0])
        self.compactor = c.create_image(70, 175, image=self.compaction_frames[0][0])
        self.status = self.label(137, 46, '')
        self.score = self.label(135, 76, '0', size=26, color=self.GREEN)
        self.label(137, 99, 'COMBO', size=9, color=self.MUTED)
        self.label(222, 64, 'BEST', size=8, color=self.MUTED)
        self.best = self.label(222, 81, '0', size=12)
        c.create_rectangle(137, 114, 295, 118, fill='#432c3d', outline='')
        self.timer = c.create_rectangle(137, 114, 137, 118, fill=self.GREEN, outline='')
        self.feed_note = self.label(137, 135, '', size=9, color=self.MUTED)
        self.packed_note = self.label(137, 168, '', size=9, color='#d0a47a')
        self.slime_src = tk.PhotoImage(file=HERE / 'slime.png')
        self.slime = c.create_image(23, 258)
        self.footer = self.label(43, 258, 'Drag to move', size=9, color=self.MUTED)
        if demo:
            for key, event in {'1': (1, 0, 0), '2': (0, 1, 0), '3': (0, 0, 1)}.items():
                root.bind(key, lambda _, e=event: self.demo_feed(*e))
            root.bind('4', lambda _: self.demo_end())
            root.bind('5', lambda _: self.combo.begin_recall(time.monotonic()-self.started))
            root.bind('6', lambda _: self.combo.cancel_recall())
            root.bind('7', lambda _: self.demo_death())
            root.bind('0', lambda _: self.demo_drop())
            root.bind('r', lambda _: self.combo.clear_match())
        else:
            Thread(target=read_game, args=(self.stop, self.snapshots), daemon=True).start()
        self.render()

    @staticmethod
    def load_frames(filename, levels, poses=1):
        source = tk.PhotoImage(file=HERE / filename)
        frames = []
        for i in range(levels):
            row = []
            for pose in range(poses):
                x, y = i * 128, pose * 128
                frame = tk.PhotoImage(width=128, height=128)
                frame.tk.call(frame, 'copy', source, '-from', x, y, x+128, y+128)
                row.append(frame)
            frames.append(row)
        return frames

    def label(self, x, y, text, size=10, color=BONE):
        return self.canvas.create_text(x, y, anchor='w', text=text, fill=color,
                                       font=('Segoe UI', size, 'bold'))

    def grab(self, event):
        self.origin = (event.x_root-self.root.winfo_x(), event.y_root-self.root.winfo_y())

    def drag(self, event):
        self.root.geometry(f'+{event.x_root-self.origin[0]}+{event.y_root-self.origin[1]}')

    def demo_feed(self, cs, kills, assists):
        if not self.combo.ended:
            now = time.monotonic() - self.started
            self.combo.expire(now)
            self.combo.feed(now, cs, kills, assists)

    def demo_end(self):
        self.combo.ended = True
        self.combo.ended_at = time.monotonic() - self.started
        self.combo.cancel_recall()

    def demo_death(self):
        if not self.combo.ended:
            self.combo.release('Death')
            self.combo.cancel_recall()

    def demo_drop(self):
        if self.combo.points and not self.combo.ended:
            self.combo.compact(time.monotonic() - self.started)

    def close(self):
        self.stop_aura()
        self.stop.set()
        self.root.destroy()

    def dismiss(self):
        if self.auto:
            self.dismissed = True
            self.stop_aura()
            self.set_visible(False)
        else:
            self.close()

    def set_visible(self, visible):
        if visible != self.visible:
            self.visible = visible
            if visible:
                self.root.deiconify()
            else:
                self.root.withdraw()

    def render(self):
        now = time.monotonic()
        try:
            while True:
                sample = self.snapshots.get_nowait()
                self.online = sample is not None
                if sample is not None:
                    if self.combo.update(sample):
                        self.dismissed = False
                        self.end_time = None
                        self.cs_cue_until = 0.0
                    if self.combo.ended and self.end_time is None:
                        self.end_time = now
                    self.sample_time = now
        except Empty:
            pass
        combo = self.combo
        if self.auto:
            live = self.online and not combo.ended
            grace = self.visible and now - (self.end_time or self.sample_time) < AUTO_HIDE_DELAY
            self.set_visible(not self.dismissed and (live or grace))
            if not self.visible:
                self.stop_aura()
                self.hide_butterfly()
                self.root.after(200, self.render)
                return
        if self.demo:
            clock = now-self.started
            if not combo.ended:
                combo.expire(clock)
                combo.advance_recall(clock)
        else:
            clock = combo.previous.clock if combo.previous else 0
            if self.online and not combo.ended:
                clock += min(1, now-self.sample_time)
        if combo.ended_at is not None:
            clock = combo.ended_at
        if self.online:
            combo.advance_butterflies(clock)
        if not combo.ended:
            combo.settle_compaction(clock)
        if combo.points and combo.cs_cues and now >= self.cs_cue_until:
            combo.cs_cues.popleft()
            self.cs_cue_until = now + .24
        cs_cue = max(0.0, self.cs_cue_until-now-.06)
        self.render_digestion(clock, cs_cue)
        self.render_butterfly(clock)
        self.render_aura(now, clock)
        status = ('MATCH ENDED' if combo.ended else 'DEMO' if self.demo else
                  'LIVE SCOREBOARD' if self.online else 'WAITING FOR GAME')
        self.canvas.itemconfigure(self.status, text=status, fill=self.GREEN if self.online else self.MUTED)
        self.canvas.itemconfigure(self.score, text=str(combo.points))
        self.canvas.itemconfigure(self.best, text=str(combo.best))
        just_fed = combo.points and 0 <= clock - combo.last < 1.2
        if combo.recall_started is not None:
            feed = 'Slime released' if combo.recall_released else f'Recall   {clock-combo.recall_started:.1f}s'
        elif combo.swallow_at is not None:
            age = clock-combo.swallow_at
            if combo.claimed_butterfly is None:
                feed = 'No butterflies'
            else:
                feed = 'Soul arriving' if age < FLIGHT_TIME else 'Watching the butterfly' if age < CONTACT_TIME else 'Swallow'
        elif combo.points:
            feed = '+1 CS' if cs_cue else combo.last_feed
        else:
            feed = 'Compacting' if combo.compacting else 'Waiting for a bite'
        self.canvas.itemconfigure(self.feed_note, text=feed,
                                  fill=self.GREEN if just_fed or (combo.points and cs_cue) else self.MUTED)
        self.canvas.itemconfigure(self.packed_note,
                                  text='COLON   absorbing faces' if combo.compacting and combo.compacting[0].faces
                                  else f'COLON   {combo.packed:g} packed')
        left = max(0, min(1, (combo.deadline - clock) / combo.window)) if combo.points else 0
        self.canvas.coords(self.timer, 137, 114, 137+158*left, 118)
        slime = combo.slimes[-1] if combo.slimes and combo.last_release == 'Recall' else None
        if slime != self.slime_frame:
            self.slime_frame = slime
            if slime:
                image = tk.PhotoImage(width=28, height=30)
                x = (slime.size-1)*28
                image.tk.call(image, 'copy', self.slime_src, '-from', x, 0, x+28, 30)
                self.slime_icon = image
                self.canvas.itemconfigure(self.slime, image=image)
            else:
                self.canvas.itemconfigure(self.slime, image='')
        footer = (f'{slime.reason}   /   Slime {slime.size}   ·   {len(combo.slimes)} banked' if slime else
                  'Death   ·   tract cleared' if combo.last_release == 'Death' else
                  '1 CS  2 kill  3 assist  0 drop  5 recall' if self.demo else
                  'Drag to move   ·   × hides this match' if self.auto else 'Drag to move   ·   Esc to close')
        self.canvas.itemconfigure(self.footer, text=footer)
        self.render_organs(clock)
        self.refresh_shop()
        self.root.after(40, self.render)

    def hide_butterfly(self):
        for window in (self.butterfly_window, self.swallow_window, *(w for w,_ in self.flock_windows.values())):
            if window is not None:
                window.withdraw()

    @staticmethod
    def show_effect(window):
        if window.state() != 'withdrawn':
            return
        window.update_idletasks()
        user32 = ctypes.WinDLL('user32')
        user32.GetAncestor.argtypes = (wintypes.HWND,wintypes.UINT)
        user32.GetAncestor.restype = wintypes.HWND
        user32.GetWindowLongW.argtypes = (wintypes.HWND,ctypes.c_int)
        user32.SetWindowLongW.argtypes = (wintypes.HWND,ctypes.c_int,ctypes.c_long)
        hwnd = user32.GetAncestor(window.winfo_id(),2)
        if hwnd:
            style = user32.GetWindowLongW(hwnd,-20)
            user32.SetWindowLongW(hwnd,-20,style | 0x08000020)
        window.deiconify()

    @staticmethod
    def orbit_position(bug, clock, cx, cy):
        age = max(0,clock-bug.born)
        angle = bug.identity*2.4+age*.37
        radius = 1-min(1,age/.8)*.12
        return cx+(cx-35)*radius*math.cos(angle),cy+(cy-35)*radius*math.sin(angle)

    def render_flock(self, clock, cx, cy):
        entries = [(bug,None) for bug in self.combo.butterflies]+self.combo.escaping[-FLOCK_LIMIT:]
        active = {bug.identity for bug,_ in entries}
        for identity in set(self.flock_windows)-active:
            self.flock_windows.pop(identity)[0].destroy()
        for bug,exit_at in entries:
            if bug.identity not in self.flock_windows:
                window = tk.Toplevel(self.root)
                window.withdraw()
                window.overrideredirect(True)
                window.attributes('-topmost',True)
                window.attributes('-transparentcolor','#ff00ff')
                canvas = tk.Canvas(window,width=44,height=44,bg='#ff00ff',highlightthickness=0)
                canvas.pack()
                self.flock_windows[bug.identity] = window,canvas
            window,canvas = self.flock_windows[bug.identity]
            x,y = self.orbit_position(bug,clock if exit_at is None else exit_at,cx,cy)
            if exit_at is not None:
                progress = min(1,(clock-exit_at)/ESCAPE_TIME)
                x += (x-cx)*progress*.45
                y += (y-cy)*progress*.45
            if x < 22 or y < 22 or x > 2*cx-22 or y > 2*cy-22:
                window.withdraw()
                continue
            canvas.delete('all')
            spread = 6+5*abs(math.sin(clock*19+bug.identity))
            for side in (-1,1):
                tip = 22+side*spread
                canvas.create_oval(min(22,tip),11,max(22,tip),23,fill='#b9dc82',outline='#e2efbc')
                canvas.create_oval(min(22,tip),21,max(22,tip),30,fill='#6f985d',outline='#b9dc82')
            canvas.create_line(22,15,22,29,fill='#f1f9d7',width=2)
            window.geometry(f'44x44{round(x-22):+d}{round(y-22):+d}')
            self.show_effect(window)

    def render_butterfly(self, clock):
        combo = self.combo
        elapsed = clock-combo.swallow_at if combo.swallow_at is not None else -1
        if combo.ended or not self.online:
            self.hide_butterfly()
            return
        cx,cy = self.root.winfo_screenwidth()/2,self.root.winfo_screenheight()/2
        self.render_flock(clock,cx,cy)
        # Offset the mouth from the screen-center proxy for Neeko.
        cx,cy = cx+84,cy-70
        bug = combo.claimed_butterfly
        if bug is None or not 0 <= elapsed < BUTTERFLY_SEQUENCE:
            self.butterfly_id = None
            if self.butterfly_window is not None:
                self.butterfly_window.withdraw()
            if bug is None and 0 <= elapsed < EMPTY_VISIT:
                self.render_swallow(cx,cy,elapsed,empty=True)
            elif self.swallow_window is not None:
                self.swallow_window.withdraw()
            return
        identity = bug.identity
        if self.butterfly_window is None:
            window = self.butterfly_window = tk.Toplevel(self.root)
            window.withdraw()
            window.overrideredirect(True)
            window.attributes('-topmost', True)
            window.attributes('-transparentcolor', '#ff00ff')
            canvas = self.butterfly_canvas = tk.Canvas(window,width=56,height=56,bg='#ff00ff',highlightthickness=0)
            canvas.pack()
        canvas = self.butterfly_canvas
        if self.butterfly_id != identity:
            self.butterfly_id = identity
            canvas.delete('all')
            self.butterfly_wings = [canvas.create_oval(0,0,0,0,fill=color,outline='#e2efbc')
                                    for color in ('#badf89','#729759','#badf89','#729759')]
            canvas.create_line(28,22,28,34,fill='#e9f7cd',width=2)
            canvas.create_line(28,23,25,19,fill='#e9f7cd')
            canvas.create_line(28,23,31,19,fill='#e9f7cd')
        p = min(1,elapsed/FLIGHT_TIME)
        start_x,start_y = self.orbit_position(bug,combo.swallow_at,cx-84,cy+70)
        perch_x, perch_y = 31, 20
        x = start_x+(cx+perch_x-start_x)*p
        y = start_y+(cy-perch_y-start_y)*p-38*math.sin(math.pi*p)
        if elapsed >= FLIGHT_TIME:
            hover = min(1,(elapsed-FLIGHT_TIME)/WATCH_TIME)
            circle = hover*math.tau
            x = cx+perch_x+17*(math.cos(circle)-1)
            y = cy-perch_y+14*math.sin(circle)
            dive = min(1,max(0,(elapsed-FLIGHT_TIME-WATCH_TIME)/DIVE_TIME))
            dive = max(0,(dive-.28)/.72)
            x,y = x+(cx-x)*dive,y+(cy-y)*dive
        if elapsed >= CONTACT_TIME:
            fall = elapsed-CONTACT_TIME
            if fall < .96:
                angle = fall*math.tau*2.7
                x = cx+math.sin(angle)*36*fall
                y = cy+135*fall*fall
                size = 12*(1-fall/.96)
                points = []
                for u,v in ((0,0),(1,-.6),(1.2,.1),(.55,.75)):
                    points.extend((28+size*(u*math.cos(angle)-v*math.sin(angle)),
                                   28+size*(u*math.sin(angle)+v*math.cos(angle))))
                canvas.delete('all')
                canvas.create_polygon(points,fill='#a9c975',outline='#e2efbc')
                self.butterfly_window.geometry(f'56x56{round(x-28):+d}{round(y-28):+d}')
            else:
                self.butterfly_window.withdraw()
            self.render_swallow(cx,cy,elapsed)
            return
        swallow = max(0,(elapsed-CONTACT_TIME)/SWALLOW_TIME)
        scale = 1-swallow
        spread = (8+6*abs(math.sin(clock*22)))*scale
        for i, wing in enumerate(self.butterfly_wings):
            side = -1 if i < 2 else 1
            tip = 28+side*spread
            upper = i % 2 == 0
            canvas.coords(wing,min(28,tip),28-(15 if upper else 1)*scale,
                          max(28,tip),28+(2 if upper else 10)*scale)
        for item in canvas.find_all()[4:]:
            canvas.itemconfigure(item,state='hidden' if swallow > .25 else 'normal')
        self.butterfly_window.geometry(f'56x56{round(x-28):+d}{round(y-28):+d}')
        self.show_effect(self.butterfly_window)
        if elapsed >= FLIGHT_TIME:
            self.render_swallow(cx,cy,elapsed)
        elif self.swallow_window is not None:
            self.swallow_window.withdraw()

    def render_swallow(self, cx, cy, elapsed, empty=False):
        if self.swallow_window is None:
            window = self.swallow_window = tk.Toplevel(self.root)
            window.withdraw()
            window.overrideredirect(True)
            window.attributes('-topmost', True)
            window.attributes('-transparentcolor', '#ff00ff')
            self.neeko_frames = {}
            for name in ('watch','look','ready','extend','catch','close','chew','chew-alt','gulp','settle','irritated','angry'):
                self.neeko_frames[name] = tk.PhotoImage(file=str(HERE/f'face-{name}.png'))
            self.swallow_canvas = tk.Canvas(window,width=112,height=112,bg='#ff00ff',highlightthickness=0)
            self.swallow_canvas.pack()
        canvas = self.swallow_canvas
        canvas.delete('all')
        bite = elapsed-CONTACT_TIME
        if empty:
            frame = 'watch' if elapsed < .58 else 'irritated' if elapsed < 1.05 else 'angry'
        elif bite < -DIVE_TIME:
            watch = elapsed-FLIGHT_TIME
            frame = 'watch' if watch < .45 else 'look' if watch < 1.15 else 'ready'
        elif bite < 0:
            frame = 'extend' if bite < -.26 else 'catch' if bite < -.08 else 'close'
        elif bite < CHEW_TIME:
            frame = ('close','chew','chew-alt','chew')[int(bite*12)%4]
        else:
            frame = 'gulp' if bite-CHEW_TIME < .29 else 'settle'
        mx,my = 56,65
        canvas.create_image(mx,0,image=self.neeko_frames[frame],anchor='n')
        self.swallow_window.geometry(f'112x112{round(cx-mx):+d}{round(cy-my):+d}')
        self.show_effect(self.swallow_window)
        if not empty and self.butterfly_window is not None:
            self.butterfly_window.lift()

    def open_shop(self):
        if self.shop_window is not None and self.shop_window.winfo_exists():
            self.shop_window.lift()
            return
        window = self.shop_window = tk.Toplevel(self.root)
        window.title('Gut Combo · Aura shop')
        window.configure(bg=self.BG)
        window.resizable(False, False)
        window.attributes('-topmost', True)
        self.shop_balance = tk.Label(window, bg=self.BG, fg=self.GREEN, font=('Segoe UI', 11, 'bold'))
        self.shop_balance.pack(padx=18, pady=(16, 10))
        self.shop_buttons = {}
        for key, (name, mud, spirit, description) in SHOP.items():
            frame = tk.Frame(window, bg=self.BG)
            frame.pack(fill='x', padx=18, pady=6)
            tk.Label(frame, text=description, bg=self.BG, fg=self.MUTED).pack(anchor='w')
            button = tk.Button(frame, command=lambda item=key: self.purchase(item), relief='flat',
                               bg='#453041', fg=self.BONE, activebackground='#665044', activeforeground=self.BONE,
                               disabledforeground='#a39799', width=36, padx=8, pady=7)
            button.pack(fill='x', pady=(4, 0))
            self.shop_buttons[key] = button
        tk.Label(window, text='Purchased effects last this match.\nDeath clears unspent reserves.',
                 bg=self.BG, fg=self.MUTED).pack(padx=18, pady=(8, 16))
        self.refresh_shop()

    def purchase(self, key):
        self.combo.buy(key)
        self.refresh_shop()

    def refresh_shop(self):
        if self.shop_window is None or not self.shop_window.winfo_exists():
            return
        self.shop_balance.configure(text=f'{self.combo.packed:g} mud   ·   {self.combo.bladder} bladder')
        for key, button in self.shop_buttons.items():
            name, mud, spirit, _ = SHOP[key]
            owned = key in self.combo.upgrades
            affordable = self.combo.packed >= mud and self.combo.bladder >= spirit
            text = f'{name}   ·   owned' if owned else f'{name}   ·   {mud} mud / {spirit} bladder'
            button.configure(text=text, state='normal' if affordable and not owned and not self.combo.ended else 'disabled')

    def render_organs(self, clock):
        c = self.canvas
        c.delete('organs')
        tag = 'organs'
        beat = max(0.0, math.sin(clock*7))**4
        swell = beat*(2.5 if self.combo.heart else .7)
        x,y = 163,210
        shape = (x,y+15+swell,x-20-swell,y-2,x-14-swell,y-16-swell,
                 x,y-9,x+14+swell,y-16-swell,x+20+swell,y-2)
        c.create_polygon(shape, smooth=True, splinesteps=18, fill='#995768', outline='#dd9a9c',
                         width=2, tags=tag)
        c.create_line(x-7,y-9,x-11,y-3,fill='#f0b0a5',width=2,tags=tag)
        for i, held in enumerate(self.combo.heart[-3:]):
            age = max(0.0, min(1.0,(clock-held.entered)/HEART_HOLD))
            px = x+(i-1)*7+math.sin(clock*11+i)*beat
            py = y-2+math.sin(clock*5+i)*2
            self.draw_face(px, py, held.soul, .65*(1-.52*age))
        c.create_text(x,y+26,text=f'HEART  {len(self.combo.heart)}',fill=self.MUTED,
                      font=('Segoe UI',8,'bold'),tags=tag)
        x,y = 255,211
        c.create_line(x-5,y-25,x-5,y-12,fill='#9cbda1',width=3,tags=tag)
        c.create_oval(x-18,y-15,x+18,y+17,fill='#334146',outline='#90b3aa',width=2,tags=tag)
        fill = 1-math.exp(-self.combo.bladder/22)
        if fill:
            c.create_arc(x-16,y-13,x+16,y+15,start=180+90*(1-fill),extent=180*fill,
                         fill='#a8c67d',outline='#cce39f',style='chord',tags=tag)
        c.create_text(x,y+25,text=f'BLADDER  {self.combo.bladder}',fill=self.GREEN,
                      font=('Segoe UI',8,'bold'),tags=tag)

    def render_digestion(self, clock, cs_cue=0):
        gut = self.combo.digestion
        if not self.combo.ended:
            gut.advance(clock)
        draining = 0.0
        packed = self.combo.packed
        self.canvas.delete('digestion-detail')
        for batch in self.combo.compacting:
            age = max(0.0, clock - batch.start)
            fraction = min(1.0, age / batch.duration)
            draining += batch.mass * (1-fraction)
            packed += batch.mass * fraction
        stomach_target = 1 - math.exp(-gut.stomach / 7)
        collector_target = 1 - math.exp(-(gut.collected + draining) / 27)
        packed_target = 1 - math.exp(-packed / 48)
        self.stomach_fill += (stomach_target-self.stomach_fill) * .24
        self.collector_fill += (collector_target-self.collector_fill) * .16
        self.packed_fill += (packed_target-self.packed_fill) * .20
        stomach_level = round(self.stomach_fill*(FRAME_COUNT-1))
        collector_level = round(self.collector_fill*(FRAME_COUNT-1))
        feed_age = max(0, clock - self.combo.last)
        pulse = round(2 * max(0, 1 - feed_age / .4, cs_cue / .18)) if self.combo.points else 0
        bowel_frame = 0
        if gut.departure is not None:
            age = max(0.0, clock-gut.departure)
            pulse = max(pulse, round(4 * max(0.0, 1-age/.45)))
            bowel_frame = 1 + min(BOWEL_FRAMES-2, int(age / gut.TRAVEL_TIME * (BOWEL_FRAMES-1)))
        self.canvas.itemconfigure(self.stomach, image=self.stomach_frames[stomach_level][pulse])
        self.canvas.itemconfigure(self.bowel, image=self.bowel_frames[bowel_frame][0])
        self.canvas.itemconfigure(self.collector, image=self.collector_frames[collector_level][0])
        self.canvas.itemconfigure(self.compactor,
                                  image=self.compaction_frames[round(self.packed_fill*(FRAME_COUNT-1))][0])
        for soul in gut.souls[-5:]:
            age = max(0, min(1, (clock-soul.born)/(soul.melt_at-soul.born)))
            x = 54 + (soul.lane % 5) * 8.5 + math.sin(age*7 + soul.lane)*2
            y = 65 + age*9 + math.sin(age*12 + soul.lane)*2
            self.draw_soul(x, y, soul, age)
        for soul in gut.liquid_faces[-5:]:
            x = 54 + (soul.lane % 5)*8.5 + math.sin(clock*4+soul.lane)*2
            self.draw_face(x, 75 + math.sin(clock*5+soul.lane)*2, soul, .77)
        if gut.bolus_faces:
            progress = (clock-gut.departure)/gut.TRAVEL_TIME
            for i, soul in enumerate(gut.bolus_faces[:5]):
                x, y = self.bowel_position(progress - .025*i)
                self.draw_face(x, y, soul, .66)
        waiting = [*gut.collector_faces]
        for batch in self.combo.compacting:
            waiting.extend(soul for i, soul in enumerate(batch.faces) if batch.face_progress(clock, i) < 0)
        for i, soul in enumerate(waiting[-6:]):
            x = 58 + (i % 3)*12 + math.sin(clock*3+i)*2
            y = 144 + (i // 3)*5 + math.sin(clock*4+i)
            self.draw_face(x, y, soul, .72)
        if self.combo.compacting:
            self.draw_compaction(self.combo.compacting[0], clock)

    def bowel_position(self, progress):
        index = max(0, min(1, progress)) * (len(self.bowel_route)-1)
        start = int(index)
        end = min(start+1, len(self.bowel_route)-1)
        part = index-start
        a, b = self.bowel_route[start], self.bowel_route[end]
        return 6+a[0]+(b[0]-a[0])*part, 30+a[1]+(b[1]-a[1])*part

    def draw_soul(self, x, y, soul, melt):
        tag = 'digestion-detail'
        radius = (7 if soul.amount == 6 else 5.3) * (1-.48*melt)
        height = radius * (1-.64*melt)
        body = '#b0cb86' if melt < .65 else '#829551'
        self.canvas.create_oval(x-radius, y-height, x+radius, y+height,
                                fill=body, outline='#677b4e', tags=tag)
        self.draw_face(x, y, soul, 1-.23*melt)

    def draw_face(self, x, y, soul, scale):
        """The face alone persists in the slurry after its blob liquefies."""
        tag = 'digestion-detail'
        if soul.amount == 4:
            scale *= .87
        edge = '#57633f'
        color = '#edf1b5'
        for side in (-1, 1):
            eye_x = x + side*2.6*scale
            eye_y = y-1.3*scale + (.45*side if soul.lane % 3 == 1 else 0)
            self.canvas.create_oval(eye_x-1.5*scale, eye_y-1.5*scale, eye_x+1.5*scale, eye_y+1.5*scale,
                                    fill=color, outline=edge, tags=tag)
            self.canvas.create_line(eye_x, eye_y-1, eye_x, eye_y+1, fill='#322939', tags=tag)
        points = (x-2.5*scale, y+2*scale, x, y+(1 if soul.lane%3 else 3.5)*scale, x+2.5*scale, y+2*scale)
        self.canvas.create_line(*points, width=max(1, 1.5*scale), fill=color, tags=tag)

    def draw_compaction(self, batch, clock):
        part = min(1.0, max(0.0, (clock-batch.start)/batch.duration))
        y = 149 + 28 * part
        self.canvas.create_line(70, y-7, 72, y, 74, y+5, fill='#b7b971', width=3,
                                smooth=True, tags='digestion-detail')
        for i, soul in enumerate(batch.faces):
            progress = batch.face_progress(clock, i)
            if 0 <= progress < 1:
                self.absorb_face(soul, i, progress)

    def absorb_face(self, soul, index, progress):
        tag = 'digestion-detail'
        side = -1 if index % 2 else 1
        wall = 72 + side*24
        anchor = 72 + side*11
        y = 171 + (index % 3)*4
        if progress < .10:
            self.draw_face(72+(anchor-72)*progress/.10, y, soul, 1.12)
            return

        pull = max(0.0, (progress-.27)/.73)
        scale = 1 if soul.amount == 6 else .86
        shiver = .7*math.sin(progress*95)*(1-pull)
        x = anchor+(wall-anchor)*pull**1.3
        if pull:
            # Echoes keep the complete expression while the front edge stretches into the wall.
            echoes = ('#503f49', '#615757') if pull > .80 else ('#5a6460', '#88a082')
            for delay, color in zip((.34, .16), echoes):
                echo = max(0.0, pull-delay)
                echo_x = anchor+(wall-anchor)*echo**1.3
                self.scream(echo_x, y-7*echo, 6*scale*(1-.52*pull),
                            7*scale*(1-.45*pull), color)
            streak = '#575653' if pull > .88 else '#75947d'
            for height in (-5, 0, 5):
                self.canvas.create_line(anchor, y+height, x, y+height*.5-5*pull,
                                        wall, y-7, smooth=True, fill=streak, tags=tag)
            self.canvas.create_arc(wall-5, y-14, wall+5, y+1, start=90 if side < 0 else 270,
                                   extent=95, style='arc', outline='#b2ce9e', width=2, tags=tag)
        radius = scale*(6+6*math.sin(math.pi*pull))*(1-.91*pull**3)
        height = scale*7*(1-.92*pull**2)
        color = '#e6f9c8' if pull < .75 else '#b2ce9e'
        self.scream(x, y-7*pull+shiver, radius, height, color, lead=True)

        for offset, eye in ((.12, -1), (.24, 1), (.36, -1)):
            fall = (progress-offset)/.43
            if 0 < fall < 1:
                tear_x = anchor+eye*4+(wall-anchor)*fall**2
                tear_y = y-2+9*math.sin(math.pi*fall)-7*fall
                self.canvas.create_line(tear_x-side*3, tear_y+1, tear_x, tear_y,
                                        fill='#91bfb1', tags=tag)
                self.canvas.create_oval(tear_x-1, tear_y-1.5, tear_x+1, tear_y+1.5,
                                        fill='#d9efcb', outline='', tags=tag)

    def scream(self, x, y, radius, height, color, lead=False):
        tag = 'digestion-detail'
        self.canvas.create_oval(x-radius, y-height, x+radius, y+height,
                                outline=color, width=2 if lead else 1, tags=tag)
        if radius < 1.4 or height < 1.5:
            return
        for side in (-1, 1):
            self.canvas.create_line(x+side*radius*.60, y-height*.53,
                                    x+side*radius*.32, y-height*.25,
                                    x+side*radius*.13, y-height*.40,
                                    fill=color, tags=tag)
        self.canvas.create_oval(x-radius*.29, y-height*.10, x+radius*.29, y+height*.68,
                                outline=color, fill='#302739' if lead else '', tags=tag)

    def toggle_sound(self):
        self.sound = not self.sound
        self.canvas.itemconfigure(self.sound_button, fill=self.GREEN if self.sound else self.MUTED)
        if not self.sound:
            self.stop_aura()

    def stop_aura(self):
        if self.aura_active:
            try:
                winsound.PlaySound(None, 0)
            except RuntimeError:
                pass
            self.canvas.delete('aura')
            self.aura_active = False

    def render_aura(self, now, clock):
        swallow = self.combo.aura_at
        age = clock-swallow if swallow is not None else -1
        if not 0 <= age < AURA_TIME or self.combo.ended or not self.online:
            self.stop_aura()
            return
        self.canvas.delete('aura')
        if self.aura_active and self.aura_start != swallow:
            self.stop_aura()
        if not self.aura_active:
            self.next_sound = now
            self.aura_active = True
            self.aura_start = swallow
        streams = 3
        for i in range(streams):
            phase = (clock*.48 + i*.39) % 1
            x = (23, 113, 31)[i]
            y = (130, 175, 192)[i] - phase*47
            bend = math.sin(phase*math.tau)*6
            color = '#476750' if phase > .75 else '#749260'
            self.canvas.create_line(x, y+10, x+bend, y+3, x-2, y-6,
                                    smooth=True, fill=color, width=2, tags='aura')
            self.canvas.create_oval(x-2, y-12, x+2, y-8, outline=color, tags='aura')
        phase = age % 5
        if phase < 1.35:
            self.canvas.create_text(91,190-phase*20,text='GLUG  GLUG  GLUG',fill='#b8d69b',
                                    font=('Segoe UI',8,'bold'),tags='aura')
        if phase < 2.2:
            phrases = ('Help...', 'I am still here.', 'Look at me.', 'Please...')
            phrase = phrases[int(age//5)] if 'whispers' in self.combo.upgrades else 'Help...'
            self.canvas.create_text(71+math.sin(phase*2)*5,111-phase*11,text=phrase,
                                    fill='#a3c09b',font=('Segoe UI',8,'italic'),tags='aura')
        if 'sparks' in self.combo.upgrades:
            for i in range(4):
                phase = (clock*.32+i*.25)%1
                x=20+i*30+math.sin(clock*2+i)*7
                y=196-phase*94
                self.canvas.create_oval(x-3,y-3,x+3,y+3,outline='#af9bc3',tags='aura')
                self.canvas.create_line(x-1,y,x-1,y+1,x+1,y+1,x+1,y,
                                        fill='#c3b9cd',tags='aura')
        if self.sound and now >= self.next_sound:
            variants = range(3,6) if 'gurgles' in self.combo.upgrades else range(3)
            clip = HERE / f'gurgle-{random.choice(variants)}.wav'
            try:
                winsound.PlaySound(str(clip), winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
            except RuntimeError:
                self.sound = False
                self.canvas.itemconfigure(self.sound_button, fill=self.MUTED)
            self.next_sound = now + random.uniform(7, 10) / math.sqrt(streams)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--demo', action='store_true', help='Manual demo without League')
    mode.add_argument('--auto', action='store_true', help='Show the meter only during a match')
    parser.add_argument('--startup-shortcut', type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    # A Windows session mutex allows the logon shortcut and its immediate launch to overlap.
    handle = None
    if args.auto:
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.CreateMutexW.argtypes = (wintypes.LPVOID, wintypes.BOOL, wintypes.LPCWSTR)
        kernel.CreateMutexW.restype = wintypes.HANDLE
        kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
        handle = kernel.CreateMutexW(None, False, r'Local\ElasticGrotesqueGutCombo')
        if not handle:
            raise ctypes.WinError(ctypes.get_last_error())
        if ctypes.get_last_error() == 183:
            kernel.CloseHandle(handle)
            return
    try:
        root = tk.Tk()
        meter = Meter(root, args.demo, args.auto)
        if args.startup_shortcut:
            def check_shortcut():
                if args.startup_shortcut.is_file():
                    root.after(1000, check_shortcut)
                else:
                    meter.close()
            root.after(1000, check_shortcut)
        root.mainloop()
    finally:
        if handle:
            kernel.CloseHandle(handle)


if __name__ == '__main__':
    main()
