param([switch]$Disable)
$ErrorActionPreference = 'Stop'
$startup = [Environment]::GetFolderPath('Startup')
if (!$startup) { throw 'Windows Startup folder could not be found.' }
$shortcutPath = Join-Path $startup 'Elastic Grotesque Gut Combo.lnk'
if ($Disable) {
    if (Test-Path -LiteralPath $shortcutPath) {
        Remove-Item -LiteralPath $shortcutPath
    }
    Write-Host 'Gut Combo auto-launch disabled.'
    exit
}

$python = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'
if (!(Test-Path -LiteralPath $python)) {
    $python = & py -3 -c 'import sys; print(sys.executable)'
    if ($LASTEXITCODE -ne 0) { throw 'Python 3 with Tkinter is required.' }
}
$pythonw = Join-Path (Split-Path -LiteralPath $python) 'pythonw.exe'
if (!(Test-Path -LiteralPath $pythonw)) { throw 'Python windowed launcher was not found.' }
$app = Join-Path $PSScriptRoot 'gut_combo.py'
$arguments = '"{0}" --auto --startup-shortcut "{1}"' -f $app, $shortcutPath
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $pythonw
$shortcut.Arguments = $arguments
$shortcut.WorkingDirectory = $PSScriptRoot
$shortcut.Description = 'Show the Gut Combo meter when League enters a match'
$shortcut.Save()
Start-Process -FilePath $pythonw -ArgumentList $arguments -WindowStyle Hidden
Write-Host 'Gut Combo auto-launch enabled.'
