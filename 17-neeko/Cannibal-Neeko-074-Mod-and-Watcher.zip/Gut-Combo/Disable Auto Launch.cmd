@echo off
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0Auto Launch.ps1" -Disable
if errorlevel 1 pause
