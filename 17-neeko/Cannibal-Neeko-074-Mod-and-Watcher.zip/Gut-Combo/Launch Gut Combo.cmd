@echo off
setlocal
set "GUT_PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if exist "%GUT_PY%" (
    "%GUT_PY%" "%~dp0gut_combo.py" %*
) else (
    py -3 "%~dp0gut_combo.py" %*
)
if errorlevel 1 pause
