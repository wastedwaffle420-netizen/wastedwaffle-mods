@echo off
call "%~dp0Launch Gut Combo.cmd" --demo
