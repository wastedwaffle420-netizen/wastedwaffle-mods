ELASTIC GROTESQUE / GUT COMBO

Extract this folder to a permanent location. Open Enable Auto Launch.cmd
once to start the hidden watcher now and at Windows sign-in. It shows the
meter when the match feed becomes available and hides it after the match.
Use Borderless mode or a second monitor. Drag to place it. Esc or × hides
it for the current match. Disable Auto Launch.cmd stops the watcher and
removes its startup shortcut.

Launch Gut Combo.cmd also opens the meter manually.
The app uses Python 3.10+ with Tkinter. It needs no Python packages.

Each scoreboard CS is one point, each assist is four, and each kill is six.
A CS gain flashes the feed label, nudges the stomach, and gives the chain
35 seconds to find the next bite. Kills and assists give 60 seconds and
feed the stomach with soul blobs. They melt into fluid, but their faces
travel through the coils and float in the collector. All CS from a
batched scoreboard update still count, with a bite cue for each point.
Starting the app mid-match sets a baseline from the current scoreboard.

Score goes into the stomach first. About every three seconds, the stomach
squeezes a portion through the intestinal coils. That bolus raises the fluid
level in the collector when it arrives. When the combo drops, the collector
drains into the colon. Each face opens in a scream, sheds tears, and is
pulled whole into the wall in a trail of ghostly afterimages.
Packed mud stays there across combos. Death clears
the tract. A match end freezes the final state.
Green wisps and gurgles run during a combo. The music-note button or M
toggles the gurgles.

Shop ($)
Each kill or assist sends one butterfly. When Neeko gulps it, one face
enters digestion. The absorbed face earns base bladder points after
nine seconds in the heart (six for a kill, four for an assist).
Minion CS and swallowed takedowns provide mud after compaction.
CS alone never earns bladder points.

The shop has 83 upgrades across Scaling, Comfort, Cosmetics and Mischief.
Scaling and Comfort use bladder, Cosmetics use mud, and Mischief uses both.
Long Chain adds cumulative yield bonuses at 25, 45, 70 and 100 seconds.
Soul Yield increases points per face. The face count stays the same.

Purchases have no cap. Buying the whole catalog costs 2,927 mud and
924 bladder points before any losses. Death clears balances,
pending souls, and active upgrades. Recall releases mud while retaining heart and bladder reserves.
Each successful purchase animates the toilet for about 2.65 seconds.

Preview Gut Combo.cmd opens the same widget in manual demo mode.
Click the window for focus. Use 1 for CS, 2 for a kill, 3 for an assist,
0 to drop the combo, 5 to start a recall, 6 to cancel it, 7 for death,
4 to end the demo match, and R to reset. The recall releases at seven
seconds in the preview. The companion has no verified live recall signal.

Use skin build 039 if you want to remove build 040's on-model passive meter.


Heart pressure
Faces batch together. Larger batches process more slowly but yield more per
face. Kills within 10 seconds add streak value to their faces. A kill during
a batch pumps the heart, raises payout, and extends the batch up to 30 seconds.
Swallowed assists add 12 extra mud. Above 40 packed mud, reserves grow over time.
At 55 bladder points, leaks begin after 14 seconds, one point every three
seconds. Kills restart the grace period. Pressure Proof costs 90, stops
leaks, and adds 3 points per face. Pressure Valve delays leaking once per
life. Early Discharge unlocks a manual heart payout.

Soul tally
Processed counts faces paid out by the heart. Escaped counts butterflies
that left the flock. Pending tracks souls still in the pipeline. Lost tracks
unfinished souls cleared by death or recall. The match screen shows pending
souls as unfinished. Each new life starts with four bladder points per 15
points of match peak bladder, capped at 40. Other death resets still apply.

Final-Thoughts count swallowed souls in the current combo before compaction.
Escaped Thoughts count those cleared from that tray by death. Butterflies
that flew away are counted separately. Colon interest produces face puffs.
