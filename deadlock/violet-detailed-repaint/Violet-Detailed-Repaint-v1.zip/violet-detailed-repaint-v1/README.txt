VIOLET - DETAILED SKIN REPAINT v1
by WastedWaffle

CREDIT WHERE IT IS DUE:
The model is FROGGONE's "Nude Violet" for Deadlock (GameBanana).
He did the modeling work that took her clothes off - this repaint
exists because his mod does. Original mod:
https://gamebanana.com/mods/728533
Author: https://gamebanana.com/members/5317755
Go support his page. This release is a texture repaint of his
barefoot version, shared with full credit to him.

WHAT THIS IS:
A full hand-painted skin detail pass over Froggone's barefoot
Nude Violet. Every other Violet mod makes her bigger or leaves
her mannequin-smooth - this one keeps her exactly as thin as she
is and gives her actual SKIN:

- Full leg repaint: freckles, moles, skin texture variation,
  detailed feet (bones, veins, sinew - never doll feet)
- Full torso repaint: a neat front seam with prickles, a mound
  wart, freckles and moles placed one by one, nothing mirrored
- A back detail found the hard way: a UV seam hunt, a marker
  expedition, and twenty versions of iteration until the crease
  read right in game - visible when she runs, without taking
  over her whole butt
- Two small cheek details flanking the crack, sized and placed
  by in-game testing until both sides matched

She reads as a person now, not a mannequin. That was the whole
point and it took all day. Worth it.

INSTALL:
1. Put pak122_dir.vpk in Deadlock/game/citadel/addons
2. If you have Froggone's original Nude Violet pak installed,
   remove it - this pak contains the full mod with the repaint
   applied, they should not both be in addons.
3. Deadlock Mod Manager (or a gameinfo.gi with the addons search
   path) handles the rest, same as any Deadlock mod.

Requires: Deadlock. That's it.
