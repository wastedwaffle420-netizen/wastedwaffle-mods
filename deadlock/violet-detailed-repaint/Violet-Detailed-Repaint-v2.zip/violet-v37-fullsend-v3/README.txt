VIOLET v37 FULL SEND v3 (pak136) — sketchbook fix. LOCAL ONLY.
Publishability: POSTABLE line once verified. Supersedes pak135.

THE SKETCHBOOK: the cover art the game actually shows is the big
green carved plate — and that plate lives on the STICKERS sheet,
not the portfolio sheet. My whole sticker scene was painted on the
portfolio sheet's brown base (the cover's back/base), so the front
still showed the stock carving. Fixed: the same scene is now
painted into the plate itself, inside its carved frame. The scene
also stays on the brown base, so the back of the cover has it too.

Everything else is pak135 exactly: pak126 base (model + materials),
v36 peach skin, alpha fixed (255), pin apron + squishie orb,
blue inkpot, brush + plushie charm, head paint. Paper stock.

INSTALL: replaces everything Violet. Pull the others, pak136 only.
